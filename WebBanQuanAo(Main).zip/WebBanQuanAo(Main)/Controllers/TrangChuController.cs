﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebBanQuanAo_Main_.Controllers
{
    public class TrangChuController : Controller
    {
        // GET: TrangChu
        public ActionResult TrangChu()
        {
            return View();
        }
        public ActionResult TrangChuNam()
        {
            return View();
        }
        public ActionResult TrangChuTreEm()
        {
            return View();
        }
        public ActionResult DanhSachSanPham()
        {
            return View();
        }
        public ActionResult DanhSachSanPhamNam()
        {
            return View();
        }
        public ActionResult DanhSachSanPhamTreEm()
        {
            return View();
        }
        public ActionResult YeuThich()
        {
            return View();
        }
        public ActionResult GioHang()
        {
            return View();
        }
        public ActionResult DangNhap()
        {
            return View();
        }
        public ActionResult DangKi()
        {
            return View();
        }
        public ActionResult TaiKhoan()
        {
            return View();
        }
        public ActionResult ThanhToan()
        {
            return View();
        }
       
        //ChiTietSanPhamNu
        public ActionResult QuanTay()
        {
            return View();
        }
        public ActionResult ChiTietSanPham()
        {
            return View();
        }
        public ActionResult AoLongXu()
        {
            return View();
        }
        public ActionResult AoPolo()
        {
            return View();
        }
        public ActionResult HighJean()
        {
            return View();
        }
        public ActionResult QuanJDaiRong()
        {
            return View();
        }
        public ActionResult QuanOngRong()
        {
            return View();
        }
        public ActionResult QuanShortGVay()
        {
            return View();
        }
        public ActionResult QuanXepLy()
        {
            return View();
        }
        public ActionResult Sweater()
        {
            return View();
        }
        public ActionResult VayJearsey()
        {
            return View();
        }
        public ActionResult VayTunic()
        {
            return View();
        }
        //CHITIETSPNAM
        public ActionResult AoDenim()
        {
            return View();
        }
        public ActionResult AoNiTayDai()
        {
            return View();
        }
        public ActionResult BaggyJean()
        {
            return View();
        }
        public ActionResult LooseJean()
        {
            return View();
        }
        public ActionResult AoSoMi()
        {
            return View();
        }
        public ActionResult AoPoloN()
        {
            return View();
        }
        public ActionResult AoTayDai()
        {
            return View();
        }
        public ActionResult AoThunLuoi()
        {
            return View();
        }
        public ActionResult AoBomber()
        {
            return View();
        }
    }
}